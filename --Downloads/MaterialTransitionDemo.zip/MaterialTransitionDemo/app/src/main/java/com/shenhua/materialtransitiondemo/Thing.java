package com.shenhua.materialtransitiondemo;

public class Thing {
    public String text;
    public String color;
    public Thing(String text, String color) {
        this.text = text;
        this.color = color;
    }
}
