# SwipeToRefreshLayout
a SwipeToRefreshLayout extents ViewGroup that childView suppsort ListView GirdView RecyclerView and any view can scroll!

Screenshot:
------------
![](https://github.com/shenhuanet/SwipeToRefreshLayout/blob/master/Screenshot.gif)
