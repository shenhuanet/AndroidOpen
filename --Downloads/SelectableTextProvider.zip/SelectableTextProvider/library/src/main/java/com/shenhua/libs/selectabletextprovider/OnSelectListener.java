package com.shenhua.libs.selectabletextprovider;

/**
 * Created by shenhua on 3/15/2017.
 * Email shenhuanet@126.com
 */
public interface OnSelectListener {

    void onTextSelected(CharSequence content);

}
