package com.shenhua.libs.selectabletextprovider;

/**
 * Created by shenhua on 3/15/2017.
 * Email shenhuanet@126.com
 */
public class SelectionInfo {

    public int mStart;
    public int mEnd;
    public String mSelectionContent;

}
