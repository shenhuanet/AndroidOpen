# PullDownFilterDemo
A Pull Down Fiter View demo.

Screenshot：
------------
![](https://github.com/shenhuanet/PullDownFilterDemo/blob/master/Screenshot.gif)
