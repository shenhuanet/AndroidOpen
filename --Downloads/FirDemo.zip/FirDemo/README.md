#FirUpdater

[ ![jCenter](https://img.shields.io/badge/version-2.0-yellowgreen.svg) ](https://dl.bintray.com/shenhuanetos/maven/com/shenhua/libs/fir-updater/2.0/)
[![Build Status](https://img.shields.io/travis/rust-lang/rust/master.svg)](https://bintray.com/shenhuanetos/maven/fir-updater)
[![Hex.pm](https://img.shields.io/hexpm/l/plug.svg)](https://www.apache.org/licenses/LICENSE-2.0.html)

A online update library for Android base fir.im.

## how to use:

#####1.Dependencies
```
dependencies {
    compile 'com.shenhua.libs:firupdater:2.0'
}
```
#####2.Code
If you need automatic updates, use the following code
```java
FirUpdater.getInstance().updatesAuto(this,API_TOKEN);
```

If you need to manually update, use the following code
```java
FirUpdater.getInstance().updatesManual(this,API_TOKEN);
```

The most important thing is you must use the following code to release the FirUpdater!
```java
FirUpdater.getInstance().onDestroy();
```

## Developed By

 * shenhua - <shenhuanet@126.com>

## License
Copyright 2016 Shenhua  ShenhueNet OS.