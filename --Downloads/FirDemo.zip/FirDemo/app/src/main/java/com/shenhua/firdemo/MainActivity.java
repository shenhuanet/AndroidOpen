package com.shenhua.firdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.shenhua.libs.firupdater.FirUpdater;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public static String API_TOKEN = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirUpdater.getInstance().updateAuto(this, API_TOKEN);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FirUpdater.getInstance().onDestroy();
    }

    public void check(View view) {
        FirUpdater.getInstance().updateManual(this, API_TOKEN);
    }
}
