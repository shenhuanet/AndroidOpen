package com.shenhua.libs.httplib.mvp.presenter;

import com.shenhua.libs.httplib.mvp.contract.BaseContract;

/**
 * Created by shenhua on 2017/04/07
 */
public interface BasePresenterImpl<V extends BaseContract.BaseView> extends BaseContract.BasePresenter {

}