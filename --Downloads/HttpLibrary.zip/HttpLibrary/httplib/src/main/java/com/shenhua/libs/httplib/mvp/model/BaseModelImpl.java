package com.shenhua.libs.httplib.mvp.model;

import com.shenhua.libs.httplib.mvp.contract.BaseContract;

/**
 * Created by shenhua on 2017/04/07
 */
public interface BaseModelImpl<T> extends BaseContract.BaseModel {

}