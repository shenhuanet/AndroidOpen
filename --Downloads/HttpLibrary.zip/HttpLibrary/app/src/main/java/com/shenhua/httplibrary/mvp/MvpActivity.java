package com.shenhua.httplibrary.mvp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.shenhua.httplibrary.R;

public class MvpActivity extends AppCompatActivity implements HomeView {

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mvp);
        progressBar = (ProgressBar) findViewById(R.id.progress);
    }

    public void doFirst(View view) {
        HomePresenter homePresenter = new HomePresenter();
        homePresenter.execute(this);
    }

    @Override
    public void showLoading(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoading() {
        progressBar.setVisibility(View.INVISIBLE);
    }

    @Override
    public void showError(String msg, View.OnClickListener onClickListener) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        progressBar.setOnClickListener(onClickListener);
    }

    @Override
    public void showEmpty(String msg, View.OnClickListener onClickListener) {

    }

    @Override
    public void showEmpty(String msg, View.OnClickListener onClickListener, int imageId) {

    }

    @Override
    public void showNetError(View.OnClickListener onClickListener) {

    }

    @Override
    public void showSuccess(HomeBean homeBean) {
        Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
    }
}
