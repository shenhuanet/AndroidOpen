package com.shenhua.httplibrary.bean;

import java.util.List;

/**
 * Created by shenhua on 4/10/2017.
 * Email shenhuanet@126.com
 */
public class BingImages {

    /**
     * images : [{"startdate":"20170409","fullstartdate":"201704091600","enddate":"20170410","url":"/az/hprichbg/rb/ArcticFoxSibs_ZH-CN7417451993_1920x1080.jpg","urlbase":"/az/hprichbg/rb/ArcticFoxSibs_ZH-CN7417451993","copyright":"弗兰格尔岛上的北极狐，俄罗斯 (© Owen Newman/Getty Images)","copyrightlink":"http://www.bing.com/search?q=%E5%8C%97%E6%9E%81%E7%8B%90%E7%8B%B8&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170409_ArcticFoxSibs%22&FORM=HPQUIZ","wp":false,"hsh":"faacad1474cf10a8d5f6f5faf75f037e","drk":1,"top":1,"bot":1,"hs":[]},{"startdate":"20170408","fullstartdate":"201704081600","enddate":"20170409","url":"/az/hprichbg/rb/TulipFestival_ZH-CN8467334837_1920x1080.jpg","urlbase":"/az/hprichbg/rb/TulipFestival_ZH-CN8467334837","copyright":"弗农山上绽放的郁金香，华盛顿 (© Pete Saloutos/plainpicture)","copyrightlink":"http://www.bing.com/search?q=%E9%83%81%E9%87%91%E9%A6%99&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170408_TulipFestival%22&FORM=HPQUIZ","wp":true,"hsh":"2587e7cb9ba2b13b50dd321ca94f56b1","drk":1,"top":1,"bot":1,"hs":[]},{"startdate":"20170407","fullstartdate":"201704071600","enddate":"20170408","url":"/az/hprichbg/rb/KalsoyIsland_ZH-CN11586790825_1920x1080.jpg","urlbase":"/az/hprichbg/rb/KalsoyIsland_ZH-CN11586790825","copyright":"卡尔斯岛上的Kallur灯塔，法罗群岛 (© Janne Kahila/500px)","copyrightlink":"http://www.bing.com/search?q=Kallur+lighthouse&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170407_KalsoyIsland%22&FORM=HPQUIZ","wp":true,"hsh":"f4843ca15dbd58355ee78a6d47733abf","drk":1,"top":1,"bot":1,"hs":[]},{"startdate":"20170406","fullstartdate":"201704061600","enddate":"20170407","url":"/az/hprichbg/rb/PhrayaNakhonCave_ZH-CN10743752151_1920x1080.jpg","urlbase":"/az/hprichbg/rb/PhrayaNakhonCave_ZH-CN10743752151","copyright":"泰国帕亚那空山洞的 Kuha Karuhas pavilion (© Bule Sky Studio/Shutterstock)","copyrightlink":"http://www.bing.com/search?q=Kuha+Karuhas+pavilion&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170406_PhrayaNakhonCave%22&FORM=HPQUIZ","wp":true,"hsh":"17ec0c72b34c0d90938e592628cc1775","drk":1,"top":1,"bot":1,"hs":[]},{"startdate":"20170405","fullstartdate":"201704051600","enddate":"20170406","url":"/az/hprichbg/rb/FreshSalt_ZH-CN12818759319_1920x1080.jpg","urlbase":"/az/hprichbg/rb/FreshSalt_ZH-CN12818759319","copyright":"淡水和盐水在埃斯塔蒂特附近的三河河口交汇，西班牙 (© Yann Arthus-Bertrand/Getty Images)","copyrightlink":"http://www.bing.com/search?q=L'Estartit&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170405_FreshSalt%22&FORM=HPQUIZ","wp":true,"hsh":"800425f6986718006147107f1e622f39","drk":1,"top":1,"bot":1,"hs":[]},{"startdate":"20170404","fullstartdate":"201704041600","enddate":"20170405","url":"/az/hprichbg/rb/JulianAlps_ZH-CN11764181030_1920x1080.jpg","urlbase":"/az/hprichbg/rb/JulianAlps_ZH-CN11764181030","copyright":"在斯洛文尼亚侧面的朱利安阿尔卑斯山 (© Nino Marcutti/Alamy)","copyrightlink":"http://www.bing.com/search?q=%E6%9C%B1%E5%88%A9%E5%AE%89%E9%98%BF%E5%B0%94%E5%8D%91%E6%96%AF%E5%B1%B1&form=hpcapt&mkt=zh-cn","quiz":"/search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170404_JulianAlps%22&FORM=HPQUIZ","wp":true,"hsh":"db2beed58e682b73b7ac9be0fb231237","drk":1,"top":1,"bot":1,"hs":[]}]
     * tooltips : {"loading":"正在加载...","previous":"上一个图像","next":"下一个图像","walle":"此图片不能下载用作壁纸。","walls":"下载今日美图。仅限用作桌面壁纸。"}
     */

    private TooltipsBean tooltips;
    private List<ImagesBean> images;

    public TooltipsBean getTooltips() {
        return tooltips;
    }

    public void setTooltips(TooltipsBean tooltips) {
        this.tooltips = tooltips;
    }

    public List<ImagesBean> getImages() {
        return images;
    }

    public void setImages(List<ImagesBean> images) {
        this.images = images;
    }

    public static class TooltipsBean {
        /**
         * loading : 正在加载...
         * previous : 上一个图像
         * next : 下一个图像
         * walle : 此图片不能下载用作壁纸。
         * walls : 下载今日美图。仅限用作桌面壁纸。
         */

        private String loading;
        private String previous;
        private String next;
        private String walle;
        private String walls;

        public String getLoading() {
            return loading;
        }

        public void setLoading(String loading) {
            this.loading = loading;
        }

        public String getPrevious() {
            return previous;
        }

        public void setPrevious(String previous) {
            this.previous = previous;
        }

        public String getNext() {
            return next;
        }

        public void setNext(String next) {
            this.next = next;
        }

        public String getWalle() {
            return walle;
        }

        public void setWalle(String walle) {
            this.walle = walle;
        }

        public String getWalls() {
            return walls;
        }

        public void setWalls(String walls) {
            this.walls = walls;
        }
    }

    public static class ImagesBean {
        /**
         * startdate : 20170409
         * fullstartdate : 201704091600
         * enddate : 20170410
         * url : /az/hprichbg/rb/ArcticFoxSibs_ZH-CN7417451993_1920x1080.jpg
         * urlbase : /az/hprichbg/rb/ArcticFoxSibs_ZH-CN7417451993
         * copyright : 弗兰格尔岛上的北极狐，俄罗斯 (© Owen Newman/Getty Images)
         * copyrightlink : http://www.bing.com/search?q=%E5%8C%97%E6%9E%81%E7%8B%90%E7%8B%B8&form=hpcapt&mkt=zh-cn
         * quiz : /search?q=Bing+homepage+quiz&filters=WQOskey:%22HPQuiz_20170409_ArcticFoxSibs%22&FORM=HPQUIZ
         * wp : false
         * hsh : faacad1474cf10a8d5f6f5faf75f037e
         * drk : 1
         * top : 1
         * bot : 1
         * hs : []
         */

        private String startdate;
        private String fullstartdate;
        private String enddate;
        private String url;
        private String urlbase;
        private String copyright;
        private String copyrightlink;
        private String quiz;
        private boolean wp;
        private String hsh;
        private int drk;
        private int top;
        private int bot;
        private List<?> hs;

        public String getStartdate() {
            return startdate;
        }

        public void setStartdate(String startdate) {
            this.startdate = startdate;
        }

        public String getFullstartdate() {
            return fullstartdate;
        }

        public void setFullstartdate(String fullstartdate) {
            this.fullstartdate = fullstartdate;
        }

        public String getEnddate() {
            return enddate;
        }

        public void setEnddate(String enddate) {
            this.enddate = enddate;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getUrlbase() {
            return urlbase;
        }

        public void setUrlbase(String urlbase) {
            this.urlbase = urlbase;
        }

        public String getCopyright() {
            return copyright;
        }

        public void setCopyright(String copyright) {
            this.copyright = copyright;
        }

        public String getCopyrightlink() {
            return copyrightlink;
        }

        public void setCopyrightlink(String copyrightlink) {
            this.copyrightlink = copyrightlink;
        }

        public String getQuiz() {
            return quiz;
        }

        public void setQuiz(String quiz) {
            this.quiz = quiz;
        }

        public boolean isWp() {
            return wp;
        }

        public void setWp(boolean wp) {
            this.wp = wp;
        }

        public String getHsh() {
            return hsh;
        }

        public void setHsh(String hsh) {
            this.hsh = hsh;
        }

        public int getDrk() {
            return drk;
        }

        public void setDrk(int drk) {
            this.drk = drk;
        }

        public int getTop() {
            return top;
        }

        public void setTop(int top) {
            this.top = top;
        }

        public int getBot() {
            return bot;
        }

        public void setBot(int bot) {
            this.bot = bot;
        }

        public List<?> getHs() {
            return hs;
        }

        public void setHs(List<?> hs) {
            this.hs = hs;
        }
    }
}
