package com.shenhua.httplibrary.mvp;

import android.os.Handler;
import android.os.Message;

import com.shenhua.libs.httplib.mvp.contract.BaseContract;

/**
 * Created by shenhua on 4/10/2017.
 * Email shenhuanet@126.com
 */
public class HomeModel implements BaseContract.BaseModel<HomeBean> {

    private BaseContract.BaseCallback<HomeBean> callback;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            callback.onError(1);
            callback.onFinish();
        }
    };

    void doFirst(final BaseContract.BaseCallback<HomeBean> callback) {
        this.callback = callback;
        callback.onStart();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                handler.obtainMessage(1, "okok").sendToTarget();
            }
        }).start();
    }
}
