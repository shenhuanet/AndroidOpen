package com.shenhua.httplibrary.mvp;

/**
 * Created by shenhua on 4/10/2017.
 * Email shenhuanet@126.com
 */
public class HomeBean {
}
