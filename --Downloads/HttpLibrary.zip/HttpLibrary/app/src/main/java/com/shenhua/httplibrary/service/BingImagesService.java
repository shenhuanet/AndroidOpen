package com.shenhua.httplibrary.service;

import com.shenhua.httplibrary.bean.BingImages;

import java.util.Map;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Query;
import retrofit2.http.Url;
import rx.Observable;

/**
 * Created by shenhua on 4/10/2017.
 * Email shenhuanet@126.com
 */
public interface BingImagesService {

    @POST("HPImageArchive.aspx")
    Call<String> getString(@Query("format") String format, @Query("idx") int idx, @Query("n") int n);

    @GET("HPImageArchive.aspx")
    Call<BingImages> getBingImages(@Query("format") String format, @Query("idx") int idx, @Query("n") int n);

//    @Multipart
//    @POST("images")
//    Call<ResponseBody> uploadImg(@Part);


    /**
     * 上传不确定图片数的图片
     *
     * @param url         url
     * @param description description
     * @param maps        maps
     * @return ResponseBody
     */
    @Multipart
    @POST()
    Call<ResponseBody> uploadFiles(@Url String url, @Part("filename") String description, @PartMap() Map<String, RequestBody> maps);

    @Multipart
    @POST("url")
    Observable<String> uploadUserFile(@Part("fileName") RequestBody description,@Part("file\"; filename=\"image.png\"")RequestBody img);

}
