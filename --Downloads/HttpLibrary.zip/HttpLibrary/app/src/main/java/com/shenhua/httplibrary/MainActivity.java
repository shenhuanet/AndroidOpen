package com.shenhua.httplibrary;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.shenhua.httplibrary.bean.BingImages;
import com.shenhua.httplibrary.service.BingImagesService;
import com.shenhua.libs.httplib.HttpLib;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private TextView mTextView;
    private String URL = "http://cn.bing.com/";
    private String IMG = "http://cnode-api.takwolf.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = (TextView) findViewById(R.id.textView);
    }

    public void request(View view) {
        BingImagesService service = HttpLib.getInstance().getBaseRetrofitService(this, URL).create(BingImagesService.class);
        Call<String> call = service.getString("js", 0, 6);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.d(TAG, "onResponse: " + response.body());
                mTextView.setText(response.body());
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.d(TAG, "onFailure: ");
            }
        });
    }

    public void parse(View view) {
        BingImagesService service = HttpLib.getInstance().getBaseRetrofitService(this, URL).create(BingImagesService.class);
        Call<BingImages> call = service.getBingImages("js", 0, 6);
        call.enqueue(new Callback<BingImages>() {
            @Override
            public void onResponse(Call<BingImages> call, Response<BingImages> response) {
                Toast.makeText(MainActivity.this, response.body().getImages().get(0).getCopyright(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<BingImages> call, Throwable t) {
                Toast.makeText(MainActivity.this, "失败", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
