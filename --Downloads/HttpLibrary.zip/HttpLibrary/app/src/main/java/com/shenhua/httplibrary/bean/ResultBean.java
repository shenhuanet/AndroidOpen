package com.shenhua.httplibrary.bean;

/**
 * Created by shenhua on 4/13/2017.
 * Email shenhuanet@126.com
 */
public class ResultBean {

    /**
     * result : 保存成功
     * code : null
     * message : null
     * isSuccess : true
     */

    private String result;
    private Object code;
    private Object message;
    private boolean isSuccess;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public boolean isIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }
}
