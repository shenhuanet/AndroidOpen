package com.shenhua.httplibrary;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

/**
 * Created by shenhua on 4/13/2017.
 * Email shenhuanet@126.com
 */
public class FileUtils {

    public static FileUtils getInstance() {
        return new FileUtils();
    }

    public MultipartBody.Part buildSingleImage(File file) {
        if (file == null) return null;
        RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        return MultipartBody.Part.createFormData("image", "__1__" + file.getName(), requestBody);
    }

    public MultipartBody.Part[] buildMultiImages(List<File> files) {
        if (files == null || files.size() == 0) return null;
        RequestBody requestFile;
        MultipartBody.Part[] results = new MultipartBody.Part[files.size()];
        for (int i = 0; i < files.size(); i++) {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), files.get(i));
            results[i] = MultipartBody.Part.createFormData("image", "__2__" + files.get(i).getName(), requestFile);
        }
        return results;
    }

    public Map<String, RequestBody> buildMultiImages2(List<File> files) {
        if (files == null || files.size() == 0) return null;
        Map<String, RequestBody> map = new HashMap<>();
        RequestBody requestFile;
        for (int i = 0; i < files.size(); i++) {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), files.get(i));
            map.put("image\"; filename=\"" + files.get(i).getName(), requestFile);
        }
        return map;
    }

}
