package com.shenhua.httplibrary.service;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

/**
 * Created by shenhua on 2017-08-08-0008.
 * Email shenhuanet@126.com
 */
public interface JsonPostService {

    @Headers({"Content-Type: application/json", "Accept: application/json"})
    @POST("web/v1/scanrecord/saveScanRecord")
    Call<String> getString(@Body RequestBody route);

}
