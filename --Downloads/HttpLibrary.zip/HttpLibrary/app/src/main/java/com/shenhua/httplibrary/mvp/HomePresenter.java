package com.shenhua.httplibrary.mvp;

import android.view.View;

import com.shenhua.libs.httplib.mvp.contract.BaseContract;

/**
 * Created by shenhua on 4/10/2017.
 * Email shenhuanet@126.com
 */
public class HomePresenter implements BaseContract.BasePresenter<HomeView>, BaseContract.BaseCallback<HomeBean> {

    private HomeView homeView;

    @Override
    public void execute(HomeView homeView) {
        this.homeView = homeView;
        HomeModel model = new HomeModel();
        model.doFirst(this);
    }

    @Override
    public void onStart() {
        homeView.showLoading("开始");
    }

    @Override
    public void onSuccess(HomeBean homeBean) {
        homeView.showSuccess(homeBean);
    }

    @Override
    public void onError(int code) {
        homeView.showError(code == 0 ? "error 0" : "error 1", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("点我干嘛");
            }
        });
    }

    @Override
    public void onFinish() {
        homeView.hideLoading();
    }

}
