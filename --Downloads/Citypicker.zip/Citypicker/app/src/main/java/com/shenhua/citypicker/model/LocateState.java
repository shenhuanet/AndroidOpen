package com.shenhua.citypicker.model;

/**
 * author shenhua on 2016/4/11.
 */
public class LocateState {
    public static final int LOCATING    = 111;
    public static final int FAILED      = 666;
    public static final int SUCCESS     = 888;
}
