package com.shenhua.itemanimation.adapter;

public class DataBean {

    int cover, icon;
    String title, time;

    public String getTitle() {
        return title;
    }

    public void setTypeName(String name) {
        this.title = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public int getCover() {
        return cover;
    }

    public void setCover(int cover) {
        this.cover = cover;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
